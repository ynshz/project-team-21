package conf;

import com.google.inject.AbstractModule;
import com.google.inject.Singleton;

@SuppressWarnings("unused")
public class Module extends AbstractModule {

    protected void configure() {

        // bind your injections here!
    }

}
