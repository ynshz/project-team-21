package cs361.battleships.models;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.ArrayList;
import java.util.List;

public class Ship {

	@JsonProperty private List<Square> occupiedSquares;
	public Ship() {
		occupiedSquares = new ArrayList<>();
	}
	int shipsize;
	String k;
	public Ship(String kind) {
		//TODO implement
		occupiedSquares = new ArrayList<>();
		if(kind == "MINESWEEPER"){
			shipsize = 2;
		}
		else if(kind == "DESTROYER"){
			shipsize = 3;
		}
		else if(kind == "BATTLESHIP"){
			shipsize = 4;
		}
		else{
			shipsize = 0;
		}
		k=kind;
	}
	public void setOccipiedSquares(List<Square> OS){
		occupiedSquares = OS;
	}
	public List<Square> getOccupiedSquares() {
		//TODO implement
		return occupiedSquares;
	}
	public int getSize(){
		return shipsize;
	}
	public String getKind(){
		return k;

	}

}
